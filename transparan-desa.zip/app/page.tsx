import { SiteHeader } from '@/components/site-header'
import { HeroSection } from '@/components/hero-section'
import { DataIntegration } from '@/components/data-integration'
import { StatsCards } from '@/components/stats-cards'
import { Logo } from '@/components/logo'

export default function Page() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main>
        <HeroSection />

        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <DataIntegration />
        </div>

        <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 md:py-16">
          <div className="mb-6 flex flex-col gap-1">
            <h2 className="font-heading text-2xl font-bold tracking-tight text-foreground">
              Ringkasan nasional
            </h2>
            <p className="text-sm text-muted-foreground">
              Angka terkini dari data desa yang terintegrasi.
            </p>
          </div>
          <StatsCards />
        </section>
      </main>

      <footer className="border-t border-border bg-surface">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 py-8 sm:flex-row sm:items-center sm:px-6">
          <Logo />
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TransparanDesa. Data desa untuk warga.
          </p>
        </div>
      </footer>
    </div>
  )
}
