import Link from 'next/link'
import { ChevronRight, Wallet, PieChart, BarChart3, Megaphone, TrendingUp } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { DesaHeader } from '@/components/desa/desa-header'
import { DesaSummaryCard } from '@/components/desa/desa-summary-card'
import { FeatureNavCard } from '@/components/desa/feature-nav-card'

const desa = {
  nama: 'Desa Ponggok',
  kabupaten: 'Kabupaten Klaten',
  provinsi: 'Jawa Tengah',
  penduduk: '5.200 jiwa',
  tahun: 2025,
  totalAnggaran: 'Rp 2,4 M',
  realisasi: 78,
  status: { text: 'Anggaran Wajar', tone: 'ok' as const },
}

const features = [
  {
    icon: PieChart,
    title: 'Lihat Rincian Anggaran',
    description: 'Telusuri alokasi dan belanja APBDes per bidang dalam visualisasi yang mudah dipahami.',
    target: 'Buka APBDes Visualizer',
    href: '#apbdes',
  },
  {
    icon: BarChart3,
    title: 'Bandingkan dengan Desa Lain',
    description: 'Lihat posisi desa ini dibanding desa sekitar berdasarkan anggaran dan realisasi.',
    target: 'Buka BenchmarkDesa',
    href: '#benchmark',
  },
  {
    icon: Megaphone,
    title: 'Lapor Ketidaksesuaian',
    description: 'Sampaikan temuan atau dugaan penyimpanan penggunaan dana desa secara langsung.',
    target: 'Buka LaporanWarga',
    href: '#lapor',
  },
]

export default function ProfilDesaPage() {
  return (
    <div className="min-h-dvh bg-surface">
      <SiteHeader />

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-6">
          <ol className="flex items-center gap-1.5 text-sm">
            <li>
              <Link href="/" className="text-muted-foreground transition-colors hover:text-primary">
                Beranda
              </Link>
            </li>
            <li aria-hidden="true">
              <ChevronRight className="size-4 text-muted-foreground/60" />
            </li>
            <li>
              <span className="font-medium text-foreground" aria-current="page">
                {desa.nama}
              </span>
            </li>
          </ol>
        </nav>

        {/* Header */}
        <DesaHeader
          nama={desa.nama}
          kabupaten={desa.kabupaten}
          provinsi={desa.provinsi}
          penduduk={desa.penduduk}
        />

        {/* Ringkasan cepat */}
        <section aria-label="Ringkasan anggaran" className="mt-8">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <DesaSummaryCard
              icon={Wallet}
              label={`Total Anggaran ${desa.tahun}`}
              value={desa.totalAnggaran}
              note="APBDes tahun berjalan"
            />
            <DesaSummaryCard
              icon={TrendingUp}
              label="Realisasi Anggaran"
              value={`${desa.realisasi}%`}
              progress={desa.realisasi}
              note={`Terpakai dari total ${desa.totalAnggaran}`}
            />
            <DesaSummaryCard
              icon={Wallet}
              label="Status Penilaian"
              value={desa.status.text === 'Anggaran Wajar' ? 'Wajar' : 'Perlu Ditinjau'}
              status={desa.status}
              note="Berdasarkan audit terbuka data desa"
            />
          </div>
        </section>

        {/* Navigasi fitur inti */}
        <section aria-label="Fitur utama desa" className="mt-10">
          <h2 className="font-heading text-xl font-bold tracking-tight text-foreground">
            Jelajahi data desa
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Pilih salah satu untuk melihat detail lebih lanjut.
          </p>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
            {features.map((f) => (
              <FeatureNavCard key={f.title} {...f} />
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
