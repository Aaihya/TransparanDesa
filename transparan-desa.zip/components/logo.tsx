import { Leaf, Home } from 'lucide-react'

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <Home className="size-5" aria-hidden="true" />
        <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-lime text-brand-green ring-2 ring-background">
          <Leaf className="size-2.5" aria-hidden="true" />
        </span>
      </div>
      <span className="font-heading text-lg font-bold leading-none tracking-tight text-foreground">
        Transparan<span className="text-primary">Desa</span>
      </span>
    </div>
  )
}
