'use client'

import { Pie, PieChart, Cell } from 'recharts'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart'

export interface AlokasiItem {
  kategori: string
  persen: number
  fill: string
}

interface AlokasiPieChartProps {
  data: AlokasiItem[]
}

export function AlokasiPieChart({ data }: AlokasiPieChartProps) {
  const chartConfig = data.reduce<ChartConfig>((acc, item) => {
    acc[item.kategori] = { label: item.kategori, color: item.fill }
    return acc
  }, {})

  return (
    <div className="flex flex-col items-center gap-6 lg:flex-row lg:items-center lg:gap-8">
      <ChartContainer config={chartConfig} className="aspect-square h-[240px] w-[240px]">
        <PieChart>
          <ChartTooltip
            cursor={false}
            content={<ChartTooltipContent hideLabel formatter={(value, name) => `${name}: ${value}%`} />}
          />
          <Pie
            data={data}
            dataKey="persen"
            nameKey="kategori"
            innerRadius={58}
            outerRadius={100}
            strokeWidth={2}
            stroke="var(--card)"
          >
            {data.map((item) => (
              <Cell key={item.kategori} fill={item.fill} />
            ))}
          </Pie>
        </PieChart>
      </ChartContainer>

      <ul className="grid w-full grid-cols-1 gap-3 sm:grid-cols-2 lg:flex-1">
        {data.map((item) => (
          <li key={item.kategori} className="flex items-center gap-3">
            <span
              className="size-3 shrink-0 rounded-sm"
              style={{ backgroundColor: item.fill }}
              aria-hidden="true"
            />
            <span className="flex-1 text-sm text-foreground">{item.kategori}</span>
            <span className="text-sm font-semibold tabular-nums text-muted-foreground">
              {item.persen}%
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}
